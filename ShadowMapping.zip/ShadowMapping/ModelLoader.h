#pragma once
#include <Windows.h>
#include <string>
#include <osg/Node>
#include <osg/BoundingBox>

class BBWrapper : public osg::BoundingBoxd
{
public:
		BBWrapper() :
				osg::BoundingBoxd()
		{

		}

		BBWrapper(const osg::BoundingBoxd& bb) :
				osg::BoundingBoxd(bb)
		{

		}

		BBWrapper(double xmin, double ymin, double zmin, double xmax, double ymax, double zmax) :
				osg::BoundingBoxd(xmin, ymin, zmin, xmax, ymax, zmax)
		{

		}

		BBWrapper(osg::Vec3d min, osg::Vec3d max) :
				osg::BoundingBoxd(min, max)
		{

		}

		double xsize() { return xMax() - xMin(); }
		double ysize() { return yMax() - yMin(); }
		double zsize() { return zMax() - zMin(); }
		double xhalfsize() { return xsize() * 0.5; }
		double yhalfsize() { return ysize() * 0.5; }
		double zhalfsize() { return zsize() * 0.5; }
		osg::Vec3d size() { return _max - _min; }
		osg::Vec3d halfsize() { return size() * 0.5; }
};

class ModelLoader
{
public:
	ModelLoader();
	~ModelLoader();
	static osg::Node* Load3DTiles(std::string indir);
	static osg::Node* Load3DTiles(std::string indir, osg::BoundingBox mask, bool intersects);
	static osg::Node* Load3DTiles(std::string indir, std::vector<std::string> maskTiles, bool include);
	static void CopyLeafTiles(std::string indir, std::string outdir, osg::BoundingBox bb);
	static void CopyLeafTiles(std::string indir, std::vector<std::string> tilenames, std::string outfile);
	static void Test();
	static void TileBoundary2Shapefile(std::string indir, std::string outfile);
};


class ShadowCaster
{
public:
		ShadowCaster() {};
		~ShadowCaster();
		void Initialize(std::vector<std::string> rasterFiles);
		void CastShadow(osg::BoundingBoxd bb, std::string outfile, osg::Vec3d sundir);
private:
		std::vector<void*> m_rasters;
};