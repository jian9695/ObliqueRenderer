
#include <QApplication>
#include <QDesktopWidget>
#include <QSplashScreen>
#include <QTextCodec>


#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

// Open files in binary mode
#include <fcntl.h> /*  _O_BINARY */
#include <windows.h>
#include <dbghelp.h>
#include <time.h>

#include <QFileInfo>
#include "osgDB/WriteFile"
#include "qdir.h"
#include "qfileinfo.h"
#include "osgDB/WriteFile"
#include "osgEarth/URI"

#include "osg/ComputeBoundsVisitor"
#include "osgGA/StateSetManipulator"
#include "osgViewer/ViewerEventHandlers"
#include "osgUtil/Optimizer"
#include "osg/MatrixTransform"
#include "osgGA/TrackballManipulator"
#include "osg/Texture2D"
#include "osg/Image"
#include "osgDB/writeFile"
#include "osgDB/readFile"
#include "osg/ClampColor"
#include "osg/Depth"
#include "osg/LineSegment"
#include <osg/ShapeDrawable>
#include <gdal_priv.h>
#include <ogr_spatialref.h>
#include "ogrsf_frmts.h"
#include "ModelLoader.h"
#include "ScreenOverlay.h"
#include "osgUtil/SmoothingVisitor"
#include "GrassSolar.h"
#include "osg/Material"
#include "GDAL_DS.h"
#include "osg/Texture1D"

using namespace osgDB;
using namespace OpenThreads;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  SortFileRequestFunctor
//

void printfVec3(osg::Vec3 p1, osg::Vec3 p2)
{
		printf("(%f,%f,%f),(%f,%f,%f)\n", p1.x(), p1.y(), p1.z(), p2.x(), p2.y(), p2.z());
}

class FaceVisitor
{
public:
		FaceVisitor(osg::PrimitiveSet* pset)
		{
				pSet = pset;
		}
		std::vector<unsigned int> getFaceIndices()
		{

				std::vector<unsigned int> indices;
				unsigned int idx = pSet->getNumIndices();
				unsigned int numofprims;


				if (pSet->getMode() == osg::PrimitiveSet::TRIANGLE_FAN)
				{
						numofprims = idx - 2;
						for (unsigned int i = 0; i < numofprims; i++)
						{
								indices.push_back(pSet->index(0));
								indices.push_back(pSet->index(i + 1));
								indices.push_back(pSet->index(i + 2));
						}
				}
				else if (pSet->getMode() == osg::PrimitiveSet::TRIANGLES)
				{
						for (unsigned int i = 0; i < idx; i++)
						{
								indices.push_back(pSet->index(i));
						}
				}
				else if (pSet->getMode() == osg::PrimitiveSet::TRIANGLE_STRIP)
				{
						numofprims = (idx - 2) / 2;
						for (unsigned int i = 0; i < numofprims; i++)
						{
								indices.push_back(pSet->index(i * 2));
								indices.push_back(pSet->index(i * 2 + 1));
								indices.push_back(pSet->index(i * 2 + 2));

								indices.push_back(pSet->index(i * 2 + 2));
								indices.push_back(pSet->index(i * 2 + 1));
								indices.push_back(pSet->index(i * 2 + 3));
						}

						if (numofprims + 2 % 2 != 0)
						{
								indices.push_back(pSet->index(idx - 3));
								indices.push_back(pSet->index(idx - 2));
								indices.push_back(pSet->index(idx - 1));
						}
				}
				return indices;
		}

private:
		osg::PrimitiveSet* pSet;
};

class GeometryVisitor : public osg::NodeVisitor
{
private:
		osg::ref_ptr<osg::Group> m_group;
public:
		GeometryVisitor() :osg::NodeVisitor(TRAVERSE_ALL_CHILDREN) { setNodeMaskOverride(0xffffffff); }

		void initialize()
		{
				m_group = new osg::Group();
		}

		void save(std::string filename)
		{
				osgDB::writeNodeFile(*m_group, filename);
		}

		virtual void apply(osg::Geode& node)
		{
				osg::MatrixList matlist = node.getWorldMatrices();
				osg::Matrix matWorld = osg::Matrix::identity();

				for (unsigned int i = 0; i < matlist.size(); i++)
				{
						matWorld = matlist[i] * matWorld;
				}
				bool isIdentify = (matWorld.isIdentity());
				osg::Texture* texture = dynamic_cast<osg::Texture*>(node.getStateSet()->getTextureAttribute(0, osg::StateAttribute::TEXTURE));
				osg::Texture* texture2d = dynamic_cast<osg::Texture2D*>(texture);
				m_group->addChild(&node);
				for (int i = 0; i < node.getNumDrawables(); i++)
				{
						osg::Drawable* drawable = node.getDrawable(i);
						osg::Geometry* geom = dynamic_cast<osg::Geometry*>(drawable);
						if (!geom) continue;
						//osg::ref_ptr<osg::Geometry> geomCpy = new osg::Geometry;

						osg::Vec3Array* vertices = (osg::Vec3Array*) geom->getVertexArray();
						osg::Vec2Array* uvs = (osg::Vec2Array*) geom->getTexCoordArray(0);
						osg::Vec3Array* normals = (osg::Vec3Array*) geom->getNormalArray();
						if (!normals)
						{
								osgUtil::SmoothingVisitor::smooth(*geom);
						}
						if (!texture2d)
						{
								texture = dynamic_cast<osg::Texture*>(geom->getStateSet()->getTextureAttribute(0, osg::StateAttribute::TEXTURE));
								texture2d = dynamic_cast<osg::Texture2D*>(texture);
						}
						for (int j = 0; j < geom->getNumPrimitiveSets(); ++j)
						{
								osg::PrimitiveSet* primitiveSet = geom->getPrimitiveSet(j);
								FaceVisitor visitor(primitiveSet);
								std::vector<unsigned int> indices = visitor.getFaceIndices();
								
								for (unsigned int k = 0; k < indices.size(); k++)
								{
										unsigned int index = indices[k];
										osg::Vec3 pos = (*vertices)[index];
										if (!isIdentify)
												pos = pos * matWorld;
										osg::Vec3 normal = (*normals)[index];
										osg::Vec2 uv = (*uvs)[index];
								}
						}
				}
		}
};

class ObliqueCamera : public osg::Camera
{
public:
		double _altAngle;
		double _azimuthAngle;
		osg::Vec3d _eye;
		osg::Vec3d _center;
		ObliqueCamera()
		{
				this->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
		}

		static osg::Vec3 getLightPos(double altAngle = 0, double azimuthAngle = 0)
		{
				osg::Vec3 lightDir;
				lightDir.z() = cos(osg::DegreesToRadians(90.0 - altAngle));
				double projectedLenghOnXY = cos(osg::DegreesToRadians(altAngle));
				lightDir.y() = projectedLenghOnXY * cos(osg::DegreesToRadians(azimuthAngle));
				//lightDir.x() = sqrt((projectedLenghOnXY * projectedLenghOnXY) - lightDir.y() * lightDir.y());
				lightDir.x() = projectedLenghOnXY * cos(osg::DegreesToRadians(90 - azimuthAngle));
				lightDir.normalize();
				return lightDir;
		}

		void reset(osg::BoundingBoxd bb, double altAngle = 0, double azimuthAngle = 0)
		{
				//altAngle = 0;
				//bb = osg::BoundingBoxd(-100, -100, -100, 100, 100, 100);
				osg::Vec3d minBB(bb.xMin(), bb.yMin(), bb.zMin());
				osg::Vec3d maxBB(bb.xMax(), bb.yMax(), bb.zMax());
				altAngle = osg::DegreesToRadians(altAngle);
			 azimuthAngle = osg::DegreesToRadians(azimuthAngle);
				osg::Vec3d forward(0, -cos(altAngle), sin(altAngle));
				osg::Vec3d right(1, 0, 0);
				osg::Vec3d up = forward ^ right;
				minBB -= bb.center();
				maxBB -= bb.center();
				BBWrapper localBB(minBB, maxBB);
				BBWrapper cameraSpaceBB;
				cameraSpaceBB.init();
				osg::Vec3d eye = -forward * bb.radius();
				osg::Matrixd viewMatrix = osg::Matrixd::lookAt(eye, osg::Vec3d(0, 0, 0), up);
				for (size_t i = 0; i < 8; i++)
				{
						cameraSpaceBB.expandBy(localBB.corner(i) * viewMatrix);
				}

				osg::Matrixd inverseViewMatrix = osg::Matrixd::inverse(viewMatrix);
				eye = (cameraSpaceBB.center() - osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix + bb.center();
				osg::Vec3d viewDirection = ((cameraSpaceBB.center() + osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix + bb.center()) - eye;
				osg::Vec3d center = cameraSpaceBB.center() * inverseViewMatrix + bb.center();
				this->setViewMatrixAsLookAt(eye, center, up);
				double xsize = (((cameraSpaceBB.center() - osg::Vec3d(cameraSpaceBB.xhalfsize(), 0, 0)) * inverseViewMatrix) - ((cameraSpaceBB.center() + osg::Vec3d(cameraSpaceBB.xhalfsize(), 0, 0)) * inverseViewMatrix)).length();
				double ysize = (((cameraSpaceBB.center() - osg::Vec3d(0, cameraSpaceBB.yhalfsize(), 0)) * inverseViewMatrix) - ((cameraSpaceBB.center() + osg::Vec3d(0, cameraSpaceBB.yhalfsize(), 0)) * inverseViewMatrix)).length();
				double zsize = (((cameraSpaceBB.center() - osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix) - ((cameraSpaceBB.center() + osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix)).length();
				this->setProjectionMatrixAsOrtho(-xsize * 0.5, xsize*0.5, -ysize * 0.5, ysize*0.5, 0, zsize*3);
				_eye = eye;
				_center = center;
		}

		void reset2(osg::BoundingBoxd bb, double altAngle = 0, double azimuthAngle = 0)
		{
				osg::Vec3d lightDir;
				lightDir.z() = cos(osg::DegreesToRadians(90.0 - altAngle));
				double projectedLenghOnXY = cos(osg::DegreesToRadians(altAngle));
				lightDir.y() = projectedLenghOnXY * cos(osg::DegreesToRadians(azimuthAngle));
				//lightDir.x() = sqrt((projectedLenghOnXY * projectedLenghOnXY) - lightDir.y() * lightDir.y());
				lightDir.x() = projectedLenghOnXY * cos(osg::DegreesToRadians(90 - azimuthAngle));
				lightDir.normalize();

				osg::Vec3d lightXY(lightDir.x(), lightDir.y(), 0);
				lightXY.normalize();
				osg::Vec3d right = lightXY * osg::Matrix::rotate(osg::DegreesToRadians(90.0), osg::Vec3d(0, 0, 1));
				//printfVec3(lightXY, right);

				//altAngle = 0;
				//bb = osg::BoundingBoxd(-100, -100, -100, 100, 100, 100);
				osg::Vec3d minBB(bb.xMin(), bb.yMin(), bb.zMin());
				osg::Vec3d maxBB(bb.xMax(), bb.yMax(), bb.zMax());
				altAngle = osg::DegreesToRadians(altAngle);
				azimuthAngle = osg::DegreesToRadians(azimuthAngle);
				
				osg::Vec3d forward = lightDir;
				osg::Vec3d up = forward ^ right;
				minBB -= bb.center();
				maxBB -= bb.center();
				BBWrapper localBB(minBB, maxBB);
				BBWrapper cameraSpaceBB;
				cameraSpaceBB.init();
				osg::Vec3d eye = -forward * bb.radius();
				osg::Matrixd viewMatrix = osg::Matrixd::lookAt(eye, osg::Vec3d(0, 0, 0), up);
				for (size_t i = 0; i < 8; i++)
				{
						cameraSpaceBB.expandBy(localBB.corner(i) * viewMatrix);
				}

				osg::Matrixd inverseViewMatrix = osg::Matrixd::inverse(viewMatrix);
				eye = (cameraSpaceBB.center() - osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix + bb.center();
				osg::Vec3d viewDirection = ((cameraSpaceBB.center() + osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix + bb.center()) - eye;
				osg::Vec3d center = cameraSpaceBB.center() * inverseViewMatrix + bb.center();
				this->setViewMatrixAsLookAt(eye, center, up);
				double xsize = (((cameraSpaceBB.center() - osg::Vec3d(cameraSpaceBB.xhalfsize(), 0, 0)) * inverseViewMatrix) - ((cameraSpaceBB.center() + osg::Vec3d(cameraSpaceBB.xhalfsize(), 0, 0)) * inverseViewMatrix)).length();
				double ysize = (((cameraSpaceBB.center() - osg::Vec3d(0, cameraSpaceBB.yhalfsize(), 0)) * inverseViewMatrix) - ((cameraSpaceBB.center() + osg::Vec3d(0, cameraSpaceBB.yhalfsize(), 0)) * inverseViewMatrix)).length();
				double zsize = (((cameraSpaceBB.center() - osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix) - ((cameraSpaceBB.center() + osg::Vec3d(0, 0, cameraSpaceBB.zhalfsize())) * inverseViewMatrix)).length();
				this->setProjectionMatrixAsOrtho(-xsize * 0.5, xsize*0.5, -ysize * 0.5, ysize*0.5, 0, zsize * 3);
				_eye = eye;
				_center = center;
		}
};


osg::Vec3d getLightDir(double altAngle = 0, double azimuthAngle = 0)
{
		osg::Vec3d lightDir;
		lightDir.z() = cos(osg::DegreesToRadians(90.0 - altAngle));
		double projectedLenghOnXY = cos(osg::DegreesToRadians(altAngle));
		lightDir.y() = projectedLenghOnXY * cos(osg::DegreesToRadians(azimuthAngle));
		//lightDir.x() = sqrt((projectedLenghOnXY * projectedLenghOnXY) - lightDir.y() * lightDir.y());
		lightDir.x() = projectedLenghOnXY * cos(osg::DegreesToRadians(90 - azimuthAngle));
		lightDir.normalize();
		return lightDir;
}

osg::Texture1D* createRandomColors(int num)
{
		srand(time(0));
		osg::ref_ptr<osg::Image> colorImage = new osg::Image;
		colorImage->allocateImage(num, 1, 1, GL_RGB, GL_UNSIGNED_BYTE);
		unsigned char* colorData = colorImage->data();
		for (long i = 0; i < num; i++)
		{
				*colorData++ = (char)(rand() % 256);
				*colorData++ = (char)(rand() % 256);
				*colorData++ = (char)(rand() % 256);
		}
		osg::Texture1D* texColor = new osg::Texture1D(colorImage.get());
		texColor->setResizeNonPowerOfTwoHint(false);
		return texColor;
}

class HeightVisitor : public osg::NodeVisitor
{
public:
		BBWrapper BB;
		std::vector<double> HeightField;
		int Rows;
		int Columns;
		double CellSize;
		double NoData;
		HeightVisitor() :osg::NodeVisitor(TRAVERSE_ALL_CHILDREN)
		{
				setNodeMaskOverride(0xffffffff);
				GDALAllRegister();
		}

		void Create(osg::BoundingBoxd bb, double cellsize)
		{
				NoData = -9999;
				CellSize = cellsize;
				BB = BBWrapper(bb);
				Rows = (int)(BB.ysize() / cellsize);
				while (Rows * cellsize < BB.ysize())
				{
						Rows++;
				}

				Columns = (int)(BB.xsize() / cellsize);
				while (Columns * cellsize < BB.xsize())
				{
						Columns++;
				}

				HeightField.resize(Rows * Columns);
				for (size_t i = 0; i < Rows * Columns; i++)
				{
						HeightField[i] = NoData;
				}
		}

		bool GetIndex(double x, double y, double& col, double& row)
		{
				if (x < BB.xMin() || x > BB.xMax() || y < BB.yMin() || y > BB.yMax())
						return false;
				col = (int)((x - BB.xMin()) / CellSize);
				row = (int)((BB.yMax() - y) / CellSize);
				if (col > Columns - 1)
						col = Columns - 1;
				if (row > Rows - 1)
						row = Rows - 1;
				return true;
		}

		void GetHeightRange(const osg::BoundingBoxd& bb, double& min, double& max) 
		{
				GetHeightRange(bb.xMin(), bb.xMax(), bb.yMin(), bb.yMax(), min, max);
		}

		void GetHeightRange(const BBWrapper& bb, double& min, double& max)
		{
				GetHeightRange(bb.xMin(), bb.xMax(), bb.yMin(), bb.yMax(), min, max);
		}

		void GetHeightRange(double xmin, double xmax, double ymin, double ymax, double& min, double& max)
		{
				min = DBL_MAX;
				max = -DBL_MAX;
				double x = xmin;
				while (x <= xmax)
				{
						double y = ymin;
						while (y <= ymax)
						{
								double col, row;
								if (!GetIndex(x, y, col, row))
								{
										y += CellSize;
										continue;
								}

								int index = col + row * Columns;
								double height = HeightField[index];
								if (height <= NoData)
								{
										y += CellSize;
										continue;
								}
								if (min > height)
										min = height;
								if (max < height)
										max = height;
								y += CellSize;
						}
						x += CellSize;
				}
		}

		virtual void apply(osg::Geode& node)
		{
				osg::MatrixList matlist = node.getWorldMatrices();
				osg::Matrix matWorld = osg::Matrix::identity();

				/*����goede������任 ��*/
				for (unsigned int i = 0; i < matlist.size(); i++)
				{
						matWorld = matlist[i] * matWorld;
				}

				for (int i = 0; i < node.getNumDrawables(); i++)
				{
						osg::Drawable* drawable = node.getDrawable(i);
						osg::Geometry* geom = dynamic_cast<osg::Geometry*>(drawable);
						if (!geom) continue;

						if (dynamic_cast<osg::Vec3Array*>(geom->getVertexArray()))
						{
								osg::Vec3Array* vertices = (osg::Vec3Array *)geom->getVertexArray();
								for (unsigned int k = 0; k < vertices->size(); k++)
								{
										osg::Vec3 pos = (*vertices)[k] * matWorld;
										if (pos.z() <= NoData)
												continue;
										double col, row;
										if (!GetIndex(pos.x(), pos.y(), col, row))
												continue;
										int index = col + row * Columns;
										if (HeightField[index] < pos.z())
												HeightField[index] = pos.z();
								}
						}
						else if (dynamic_cast<osg::Vec3dArray*>(geom->getVertexArray()))
						{
								osg::Vec3dArray* vertices = (osg::Vec3dArray*)geom->getVertexArray();
								for (unsigned int k = 0; k < vertices->size(); k++)
								{
										osg::Vec3d pos = (*vertices)[k] * matWorld;
										if (pos.z() <= NoData)
												continue;
										double col, row;
										if (!GetIndex(pos.x(), pos.y(), col, row))
												continue;
										int index = col + row * Columns;
										if (HeightField[index] < pos.z())
												HeightField[index] = pos.z();
								}
						}

				}
		}

		void Write(std::string outfile)
		{
				GDAL_DS<double>* ds = new GDAL_DS<double>();
				GDAL_DSInfo info;
			 memset(info.adfGeoTransform, 0, sizeof(double) * 6);
				info.adfGeoTransform[0] =	BB.xMin();
				info.adfGeoTransform[3] = BB.yMax();
				info.adfGeoTransform[1] = CellSize;
				info.adfGeoTransform[5] = -CellSize;
				info.filename = outfile;
				info.ncols = Columns;
				info.nrows = Rows;
				info.numbands = 1;
				ds->setDSInfo(&info);
				ds->create(outfile);
				ds->writeData(1, &HeightField[0], NoData);
				delete ds;
		}

private:
};


bool _canUpdateLightDir = false;

class MyKeyboardHandler : public osgGA::GUIEventHandler
{
public:

		MyKeyboardHandler() : osgGA::GUIEventHandler()
		{

		}

		bool handle(const osgGA::GUIEventAdapter& ea, osgGA::GUIActionAdapter& aa)
		{
				osgViewer::Viewer* viewer = dynamic_cast<osgViewer::Viewer*>(&aa);
				if (!viewer)
						return false;

				switch (ea.getEventType())
				{
						case(osgGA::GUIEventAdapter::KEYDOWN):
						{
								if (ea.getKey() == 'm')
								{
										_canUpdateLightDir = true;
								}
						}
				}

				return false;
		}
};

#include "osg/Point"
#include "osg/LineWidth"

osg::Geometry* createLine(std::vector<osg::Vec3> points)
{
		// create Geometry object to store all the vertices and lines primitive.
		osg::Geometry* linesGeom = new osg::Geometry();

		// this time we'll preallocate the vertex array to the size
		// and then use an iterator to fill in the values, a bit perverse
		// but does demonstrate that we have just a standard std::vector underneath.
		osg::Vec3Array* vertices = new osg::Vec3Array();
		for (size_t i = 0; i < points.size(); i++)
		{
				vertices->push_back(points[i]);
		}

		// pass the created vertex array to the points geometry object.
		linesGeom->setVertexArray(vertices);

		// set the colors as before, plus using the above
		osg::Vec4Array* colors = new osg::Vec4Array;
		colors->push_back(osg::Vec4(1.0f, 1.0f, 0.0f, 1.0f));
		linesGeom->setColorArray(colors, osg::Array::BIND_OVERALL);

		// Set the normal in the same way as the color (see note at POINTS, above).
		//osg::Vec3Array* normals = new osg::Vec3Array;
		//normals->push_back(osg::Vec3(0.0f, -1.0f, 0.0f));
		//linesGeom->setNormalArray(normals, osg::Array::BIND_OVERALL);


		// This time we simply use primitive, and hardwire the number of coords to use
		// since we know up front,
		linesGeom->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, points.size()));

		osg::ref_ptr<osg::LineWidth> lineWid = new osg::LineWidth(3.0);
		linesGeom->getOrCreateStateSet()->setAttribute(lineWid);
		return linesGeom;
}


osg::Geometry* createPoints(std::vector<osg::Vec3> points)
{
		// create Geometry object to store all the vertices and lines primitive.
		osg::Geometry* linesGeom = new osg::Geometry();

		// this time we'll preallocate the vertex array to the size
		// and then use an iterator to fill in the values, a bit perverse
		// but does demonstrate that we have just a standard std::vector underneath.
		osg::Vec3Array* vertices = new osg::Vec3Array();
		for (size_t i = 0; i < points.size(); i++)
		{
				vertices->push_back(points[i]);
		}

		// pass the created vertex array to the points geometry object.
		linesGeom->setVertexArray(vertices);

		// set the colors as before, plus using the above
		osg::Vec4Array* colors = new osg::Vec4Array;
		colors->push_back(osg::Vec4(0.0f, 1.0f, 1.0f, 1.0f));
		linesGeom->setColorArray(colors, osg::Array::BIND_OVERALL);

		// Set the normal in the same way as the color (see note at POINTS, above).
		osg::Vec3Array* normals = new osg::Vec3Array;
	//	//normals->push_back(osg::Vec3(0.0f, -1.0f, 0.0f));
		//linesGeom->setNormalArray(normals, osg::Array::BIND_OVERALL);


		// This time we simply use primitive, and hardwire the number of coords to use
		// since we know up front,
		linesGeom->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::POINTS, 0, points.size()));
		osg::Point* pointSize = new osg::Point;
		pointSize->setSize(10.0);
		linesGeom->getOrCreateStateSet()->setAttribute(pointSize);


		return linesGeom;
}

void bindColorShader(osg::StateSet* stateSet)
{
		char fragmentShaderSource[] =
				"uniform vec3 color;\n"
				"void main(void) \n"
				"{\n"
				"  gl_FragColor = vec4(color, 1);\n"
				"}\n";

		stateSet->addUniform(new osg::Uniform("color", osg::Vec3(0,0,0)));
		osg::ref_ptr<osg::Program>  program = new osg::Program;
		program->addShader(new osg::Shader(osg::Shader::FRAGMENT, fragmentShaderSource));
		stateSet->setAttribute(program.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
}

osg::BoundingBox MaskBB;

int main(int argc, char** argv)
{

		std::vector<std::string> tilenames;
		tilenames.push_back("Tile_-002_-016");
		tilenames.push_back("Tile_-002_-017");
		tilenames.push_back("Tile_-003_-016");
		tilenames.push_back("Tile_-003_-017");
		//ModelLoader::CopyLeafTiles("E:/Data/weihai/Data/", tilenames, "E:/Code/StudyArea.osgb");

		GDALAllRegister();
		ModelLoader::Test();
	//	ModelLoader::TileBoundary2Shapefile("E:/Data/weihai/Data/","TileMap.shp");
		osg::Vec3 maskBBCenter = osg::Vec3(-3945.2300, -7068.9270, 0);
		osg::Vec2 maskBBSize = osg::Vec2(1000, 1000);
		MaskBB = osg::BoundingBox(maskBBCenter.x() - maskBBSize.x() * 0.5, maskBBCenter.y() - maskBBSize.y() * 0.5, -10000,
				maskBBCenter.x() + maskBBSize.x() * 0.5, maskBBCenter.y() + maskBBSize.y() * 0.5, 10000);

		SolarParam param;
		param.aspect = 90;
		param.slope = 78;
		param.lon = 112;
		param.lat = 36;
		param.day = 183;
		param.time_step = 1;
		GrassSolar grassSolar;
		osg::ref_ptr<osg::Image> colorRampImage = osgDB::readImageFile("E:/Code/ColoEsriTemp.png");
	 //std::vector<SunVector> sunVectors =	grassSolar.getSunVectors(param);
		//sunVectors = grassSolar.getSunVectors(param);
	//	SolarRadiation rad = grassSolar.calculateSolarRadiation(param);
		//printfVec3(getLightDir(45, 0), getLightDir(45, 0));
		//printfVec3(getLightDir(45, 90), getLightDir(45, 90));
		//printfVec3(getLightDir(45, 180), getLightDir(45, 180));
		//printfVec3(getLightDir(45, 270), getLightDir(45, 270));
		//printf("%f, %f\n", 90.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 90)));

		//printf("%f, %f\n", 0.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 0)));
		//printf("%f, %f\n", 90.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 90)));
		//printf("%f, %f\n", 180.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 180)));
		//printf("%f, %f\n", 270.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 270)));
		//printf("%f, %f\n", 300.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 300.0)));
		//printf("%f, %f\n", 359.0, GrassSolar::calculateAspect(GrassSolar::solarAngle2Vector(45, 359)));

		//param.slope = 0;
		//while (param.slope <= 90)
		//{
		//		printf("%f, %f\n", param.slope, GrassSolar::calculateSlope(GrassSolar::solarAngle2Vector(param.slope, 359)));
		//		param.slope += 10;
		//}

		//printf("%f, %f\n", 85.0, GrassSolar::calculateSlope(GrassSolar::solarAngle2Vector(85.0, 359)));
		//param.slope = 0;

		//while (param.slope <= 90)
		//{
		//		rad = grassSolar.calculateSolarRadiation(param);
		//		printf("%f,%f\n", param.slope, rad.global);
		//		param.slope += 10;
		//}

		//while (param.aspect <= 360)
		//{
		//		rad = grassSolar.calculateSolarRadiation(param);
		//		printf("%f,%f\n", param.aspect, rad.global);
		//		param.aspect += 10;
		//}

	 //osg::Vec3 grassLight = GrassSolar::solarAngle2Vector(45, 0);
		//osg::Vec3 myLight = getLightDir(45, 0);
		//grassLight =	GrassSolar::solarAngle2Vector(45, 270);
		//grassLight = GrassSolar::solarAngle2Vector(45, 90);
		//grassLight = GrassSolar::solarAngle2Vector(45, 90);
		osg::DisplaySettings::instance()->setNumOfDatabaseThreadsHint(1);
		osg::DisplaySettings::instance()->setNumOfHttpDatabaseThreadsHint(0);

		std::string infile = argv[1];
		QDir qoutdir = QDir(argv[2]);
		if (!qoutdir.exists())
				qoutdir.mkdir(".");
		//DeleteDirectory(qoutdir.absolutePath());
		std::string outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();
		double resol = atof(argv[3]);
		double altAngle = atof(argv[4]);
		double azimuthAngle = atof(argv[5]);
		int texSizeX = 2048;
		int texSizeY = 2048;


		osgViewer::Viewer viewer;
		//viewer.getScene()->setDatabasePager()
		// add the state manipulator
		viewer.addEventHandler(new osgGA::StateSetManipulator(viewer.getCamera()->getOrCreateStateSet()));

		// add the thread model handler
		viewer.addEventHandler(new osgViewer::ThreadingHandler);

		// add the window size toggle handler
		viewer.addEventHandler(new osgViewer::WindowSizeHandler);

		// add the stats handler
		viewer.addEventHandler(new osgViewer::StatsHandler);

		osg::ref_ptr<osg::Node> node = ModelLoader::Load3DTiles(infile.data(), tilenames, false);
		osg::ref_ptr<osg::Node> studyArea = osgDB::readNodeFile("E:/Code/StudyArea.osgb");
		((osg::Group*)node.get())->addChild(studyArea.get());
		node->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF | osg::StateAttribute::OVERRIDE | osg::StateAttribute::PROTECTED);
		studyArea->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE | osg::StateAttribute::PROTECTED);
		viewer.setUpViewInWindow(100, 100, 1024, 768);
		viewer.realize();
		viewer.setCameraManipulator(new osgGA::TrackballManipulator);
		viewer.setSceneData(node.get());
		return viewer.run();


		node->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF | osg::StateAttribute::OVERRIDE);
		//node->getOrCreateStateSet()->setMode( GL_BLEND, osg::StateAttribute::ON|osg::StateAttribute::OVERRIDE);
		osg::ref_ptr<osg::MatrixTransform> sceneNode = new osg::MatrixTransform;
		sceneNode->addChild(node.get());

		//ObliqueCameraWrapper* orthoCamera = new ObliqueCameraWrapper(viewer.getCamera(),bb, 45);
		//viewer.getCamera()->setComputeNearFarMode(osg::CullSettings::DO_NOT_COMPUTE_NEAR_FAR);
		viewer.getCamera()->setClearMask(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		//viewer.getCamera()->setClearColor(osg::Vec4(0, 0, 0, 0));

		osg::ref_ptr<ObliqueCamera> orthoCamera = new ObliqueCamera();
		orthoCamera->setComputeNearFarMode(osg::CullSettings::DO_NOT_COMPUTE_NEAR_FAR);
		orthoCamera->setClearMask(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		orthoCamera->setClearColor(osg::Vec4(0, 0, 0, 0));

		orthoCamera->setReferenceFrame(osg::Transform::ABSOLUTE_RF_INHERIT_VIEWPOINT);
		orthoCamera->setViewport(0, 0, texSizeX, texSizeY);
		orthoCamera->setRenderOrder(osg::Camera::PRE_RENDER);
		orthoCamera->setRenderTargetImplementation(osg::Camera::FRAME_BUFFER_OBJECT);
		orthoCamera->setClearMask(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		//viewer.setUpViewInWindow(0, 0, 512, 512);
		//orthoCamera->attach(osg::Camera::COLOR_BUFFER0, tex.get());
		//orthoCamera->attach(osg::Camera::COLOR_BUFFER0, img.get());
		orthoCamera->addChild(sceneNode.get());

		osg::Matrix mat = osg::Matrix::rotate(osg::DegreesToRadians(azimuthAngle), osg::Vec3(0, 0, 1));
		sceneNode->setMatrix(mat);
		osg::ComputeBoundsVisitor visitor;
		sceneNode->accept(visitor);
		osg::BoundingBox bb = visitor.getBoundingBox();
		osg::Vec3 center = bb.center();
		osg::Vec2 bbSize(bb.xMax() - bb.xMin(), bb.yMax() - bb.yMin());

		osg::ComputeBoundsVisitor rawvisitor;
		node->accept(rawvisitor);

#pragma region 

		char shadowVertexShaderSource[] =
				"#extension GL_EXT_gpu_shader4 : enable\n"
				"uniform mat4 osg_ViewMatrixInverse;\n"
				"uniform mat4 osg_ViewMatrix;\n"
				"varying vec4 pos;\n"
				"varying vec4 normal;\n"
				"void main(void)\n"
				"{\n"
				"gl_TexCoord[0] = gl_MultiTexCoord0;\n"
				"pos =  gl_Vertex;\n"
				"normal = vec4(gl_Normal, 1);\n"
				"gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n"
				"}\n";

	char shadowFragmentShaderSource[] =
			"#extension GL_EXT_gpu_shader4 : enable\n"
			"uniform sampler2D tex;\n"
			"uniform vec3 minbound;\n"
			"uniform vec3 maxbound;\n"
			"varying vec4 pos;\n"
			"varying vec4 normal;\n"
			"void main(void) \n"
			"{\n"
			"  vec4 color = texture2D(tex, gl_TexCoord[0].xy); \n"
			"  gl_FragData[0] = pos;\n"
			"  //gl_FragData[0] = normal;\n"
			"}\n";

	char vertexShaderSource[] =
			"#extension GL_EXT_gpu_shader4 : enable\n"
			"varying vec4 pos;\n"
			"void main(void)\n"
			"{\n"
			"gl_TexCoord[0] = gl_MultiTexCoord0;\n"
			"pos =  gl_Vertex;\n"
			"gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n"
			"}\n";

	char fragmentShaderSource[] =
			"#extension GL_EXT_gpu_shader4 : enable\n"
			"uniform sampler2D tex;\n"
			"uniform sampler2D shadowTex;\n"
			"uniform vec3 minbound;\n"
			"uniform vec3 maxbound;\n"
			"uniform vec3 lightPos;\n"
			"uniform mat4 lightMatrix;\n"
			"varying vec4 pos;\n"

			"vec2 poissonDisk[4] = vec2[](\n"
			"vec2(-0.94201624, -0.39906216), \n"
			"vec2(0.94558609, -0.76890725), \n"
			"vec2(-0.094184101, -0.92938870), \n"
			"vec2(0.34495938, 0.29387760)\n"
			"); \n"

			"void main(void) \n"
			"{\n"
			"  vec3 color = texture2D(tex, gl_TexCoord[0].xy); \n"
			"  vec4 shadowUV = lightMatrix * pos; \n"
			"  if(pos.x > minbound.x && pos.x < maxbound.x && pos.y > minbound.y && pos.y < maxbound.y)\n"
			"  {\n"
			"    color = color + vec3(0.3,0,0);\n"
			"    float visibility = 1.0;\n"
			"    //for (int i = 0; i < 4; i++) \n"
			"    //{\n"
			"      //vec4 shadowPos = texture2D(shadowTex, shadowUV.xy + poissonDisk[i] / 700.0); \n"
			"      //float shadowToCamera = length(shadowPos.xyz-lightPos); \n"
			"      //float distToCamera = length(pos.xyz-lightPos); \n"
			"    	 //if(distToCamera - shadowToCamera > 0.2) \n"
			"    	 //{\n"
			"    	 //	 visibility -= 0.2;\n"
			"     	//}\n"
			"   //}\n"
			"      vec4 shadowPos = texture2D(shadowTex, shadowUV.xy); \n"
			"      float shadowToCamera = length(shadowPos.xyz-lightPos); \n"
			"      float distToCamera = length(pos.xyz-lightPos); \n"
			"    	 if(distToCamera - shadowToCamera > 0.2) \n"
			"    	 {\n"
			"         color = color * 0.6;\n"
			"     	}\n"
			"  }\n"
			"  gl_FragColor = vec4(color, 1);\n"
			"}\n";

	osg::Vec3 minbound = osg::Vec3(bb.xMin(), bb.yMin(), bb.zMin());
	osg::Vec3 maxbound = osg::Vec3(bb.xMax(), bb.yMax(), bb.zMax());
	sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("tex", 0));
	sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("minbound", minbound));
	sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("maxbound", maxbound));
	osg::ref_ptr<osg::Program> program = new osg::Program;
	program->addShader(new osg::Shader(osg::Shader::FRAGMENT, shadowFragmentShaderSource));
	program->addShader(new osg::Shader(osg::Shader::VERTEX, shadowVertexShaderSource));
	sceneNode->getOrCreateStateSet()->setAttribute(program.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
	osg::ClampColor* clamp = new osg::ClampColor();
	clamp->setClampVertexColor(GL_FALSE);
	clamp->setClampFragmentColor(GL_FALSE);
	clamp->setClampReadColor(GL_FALSE);
	sceneNode->getOrCreateStateSet()->setAttribute(clamp, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
#pragma endregion


		osg::ref_ptr<osg::Texture2D> tex = new osg::Texture2D;
		tex->setTextureSize(texSizeX, texSizeY);
		tex->setResizeNonPowerOfTwoHint(false);
		tex->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR);
		tex->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::LINEAR);
		tex->setWrap(osg::Texture2D::WRAP_S, osg::Texture2D::REPEAT);
		tex->setWrap(osg::Texture2D::WRAP_T, osg::Texture2D::REPEAT);
		//rtTexture->setDataVariance(osg::Object::DYNAMIC);
		//tex->setInternalFormat(GL_RGBA);
		tex->setSourceFormat(GL_RGBA);
		tex->setInternalFormat(GL_RGBA32F_ARB);
		tex->setSourceType(GL_FLOAT);
		//tex->setSourceType(GL_UNSIGNED_BYTE);
		osg::ref_ptr<osg::Image> img = new osg::Image;
		img->allocateImage(texSizeX, texSizeY,1,GL_RGBA,GL_FLOAT);
		//img->allocateImage(texSizeX, texSizeY, 1, GL_RGBA, GL_UNSIGNED_BYTE);
		tex->setImage(img.get());
		orthoCamera->attach(osg::Camera::COLOR_BUFFER0, tex.get());
		//orthoCamera->attach(osg::Camera::COLOR_BUFFER0, img.get());

		viewer.setUpViewInWindow(100, 100, 1024, 768);
		viewer.realize();
		viewer.setCameraManipulator(new osgGA::TrackballManipulator);

		osg::ref_ptr<osg::Group> nodeWrapper = new osg::Group;
		nodeWrapper->addChild(node.get());
		program = new osg::Program;
		program->addShader(new osg::Shader(osg::Shader::FRAGMENT, fragmentShaderSource));
		program->addShader(new osg::Shader(osg::Shader::VERTEX, vertexShaderSource));
		nodeWrapper->getOrCreateStateSet()->setAttribute(program.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
		sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("minbound", minbound));
		sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("maxbound", maxbound));
		sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("tex", 0));
		//nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform("lightMatrix", osg::Matrix::identity()));
		nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform(osg::Uniform::FLOAT_MAT4, "lightMatrix"));
		nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform("lightPos", osg::Vec3(0,0,0)));
		nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform("minbound", minbound));
		nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform("maxbound", maxbound));
		nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform("tex", 0));
		nodeWrapper->getOrCreateStateSet()->addUniform(new osg::Uniform("shadowTex", 1));
		nodeWrapper->getOrCreateStateSet()->setTextureAttribute(1, tex.get());
		//osg::ref_ptr<osg::Texture2D> tex2 = new osg::Texture2D;
		//osg::ref_ptr<osg::Image> img2 = osgDB::readImageFile("ortho.png");
		//tex2->setImage(img2.get());
		//sceneNode->getOrCreateStateSet()->addUniform(new osg::Uniform("tex", 2));

		HeightVisitor heightField;
		heightField.Create(rawvisitor.getBoundingBox(), 10);
		node->accept(heightField);

		osgDB::DatabasePager* pager = viewer.getScene()->getDatabasePager();
		osg::ref_ptr<osg::Group> root = new osg::Group;
		root->addChild(nodeWrapper.get());
		root->addChild(orthoCamera.get());
		viewer.addEventHandler(new MyKeyboardHandler());
		viewer.setSceneData(root.get());
		center = osg::Vec3(-3945.2300, -7068.9270, 0);
		bbSize = osg::Vec2(1000, 1000);
		double minz, maxz;
		BBWrapper localbb = BBWrapper(center.x() - bbSize.x() * 0.5, center.y() - bbSize.y() * 0.5, bb.zMin(),
				center.x() + bbSize.x() * 0.5, center.y() + bbSize.y() * 0.5, bb.zMax());
		heightField.GetHeightRange(localbb, minz, maxz);
		localbb = BBWrapper(center.x() - bbSize.x() * 0.5, center.y() - bbSize.y() * 0.5, minz,
				center.x() + bbSize.x() * 0.5, center.y() + bbSize.y() * 0.5, maxz);
		double scale = 1.0;
		minbound = osg::Vec3(center.x() - localbb.xhalfsize()*scale, center.y() - localbb.yhalfsize()*scale, center.z() - localbb.zhalfsize());
		maxbound = osg::Vec3(center.x() + localbb.xhalfsize()*scale, center.y() + localbb.yhalfsize()*scale, center.z() + localbb.zhalfsize());
		nodeWrapper->getOrCreateStateSet()->getUniform("minbound")->set(minbound);
		nodeWrapper->getOrCreateStateSet()->getUniform("maxbound")->set(maxbound);
		sceneNode->getOrCreateStateSet()->getUniform("minbound")->set(minbound);
		sceneNode->getOrCreateStateSet()->getUniform("maxbound")->set(maxbound);
		return viewer.run();
	//	ModelLoader::CopyLeafTiles(infile, "E:/Code/WeihaiLeafTiles/", localbb);
		//ModelLoader::Test();
		//BBWrapper localbb = bb;
		osg::Vec3 startPoint = localbb._min;
		osg::Vec3 endPoint = localbb._max;
		startPoint.z() = endPoint.z() = center.z();
		osg::Vec3 startEnd = endPoint - startPoint;
		startEnd.normalize();
		float dist = (endPoint - startPoint).length();
		float curDist = 0;

		orthoCamera->reset2(localbb, 90, 0);
		viewer.frame();
		while (pager->getRequestsInProgress())
		{
				viewer.frame();
		}

		heightField.Create(localbb, 2);
		sceneNode->accept(heightField);
		//heightField.Write("E:/Code/ljm.tif");
		osg::ref_ptr<osg::Geode> shapes = new osg::Geode;
		std::vector<osg::Vec3> points;
		std::vector<osgUtil::LineSegmentIntersector::Intersection> intersections;
		std::vector<SolarRadiation> rads;
		//osg::Vec3d lightdir = getLightDir(10, 90);
		//while (curDist <= dist)
		//{
		//		osg::Vec3 curPoint = startPoint + startEnd * curDist;
		//		osg::Vec3 start = curPoint + lightdir * 1000;
		//		osg::Vec3 end = curPoint - lightdir * 1000;
		//		//osg::ref_ptr<osgUtil::LineSegmentIntersector> intersector = new osgUtil::LineSegmentIntersector(curPoint + osg::Vec3(0, 0, 1000), curPoint - osg::Vec3(0, 0, 1000));
		//		osg::ref_ptr<osgUtil::LineSegmentIntersector> intersector = new osgUtil::LineSegmentIntersector(start, end);
		//		osgUtil::IntersectionVisitor intersectVisitor(intersector.get());
		//		sceneNode->accept(intersectVisitor);

		//		if (intersector->containsIntersections())
		//		{
		//				//for (osgUtil::LineSegmentIntersector::Intersections::iterator hitr = intersector->getIntersections().begin();
		//				//		hitr != intersector->getIntersections().end();
		//				//		++hitr)
		//				//{
		//				//		osg::TessellationHints* hints = new osg::TessellationHints;
		//				//		hints->setDetailRatio(0.5f);
		//				//		//	shapes->addDrawable(new osg::ShapeDrawable(new osg::Sphere(intersector->getFirstIntersection().getWorldIntersectPoint(), 1), hints));
		//				//		printfVec3(hitr->getWorldIntersectPoint(), hitr->getWorldIntersectNormal());
		//				//		points.push_back(hitr->getWorldIntersectPoint());
		//				//}
		//				osg::TessellationHints* hints = new osg::TessellationHints;
		//				hints->setDetailRatio(0.5f);
		//				//shapes->addDrawable(new osg::ShapeDrawable(new osg::Sphere(intersector->getFirstIntersection().getWorldIntersectPoint(), 1), hints));
		//				printfVec3(intersector->getFirstIntersection().getWorldIntersectPoint(), intersector->getFirstIntersection().getWorldIntersectNormal());
		//				points.push_back(intersector->getFirstIntersection().getWorldIntersectPoint());
		//				intersections.push_back(intersector->getFirstIntersection());
		//				rads.push_back(grassSolar.calculateSolarRadiation(param, sceneNode, intersector->getFirstIntersection()));
		//		}
		//		curDist += 20;
		//}

		double y = minbound.y();
		while (y <= maxbound.y())
		{
				double x = minbound.x();
				while (x <= maxbound.x())
				{
						osg::Vec3 end(x, y, minbound.z() - 1000);
						osg::Vec3 start(x, y, maxbound.z() + 1000);
						//osg::ref_ptr<osgUtil::LineSegmentIntersector> intersector = new osgUtil::LineSegmentIntersector(curPoint + osg::Vec3(0, 0, 1000), curPoint - osg::Vec3(0, 0, 1000));
						osg::ref_ptr<osgUtil::LineSegmentIntersector> intersector = new osgUtil::LineSegmentIntersector(start, end);
						osgUtil::IntersectionVisitor intersectVisitor(intersector.get());
						sceneNode->accept(intersectVisitor);
						if (intersector->containsIntersections())
						{
								osg::TessellationHints* hints = new osg::TessellationHints;
								hints->setDetailRatio(0.5f);
								//shapes->addDrawable(new osg::ShapeDrawable(new osg::Sphere(intersector->getFirstIntersection().getWorldIntersectPoint(), 1), hints));
								printfVec3(intersector->getFirstIntersection().getWorldIntersectPoint(), intersector->getFirstIntersection().getWorldIntersectNormal());
								points.push_back(intersector->getFirstIntersection().getWorldIntersectPoint());
								intersections.push_back(intersector->getFirstIntersection());
								rads.push_back(grassSolar.calculateSolarRadiation(param, sceneNode, intersector->getFirstIntersection()));
						}
						x += 50;
				}
				y += 50;
		}


		double maxRad = -9999999;
		double minRad = 9999999;
		for (long i = 0; i < rads.size(); i++)
		{
				if (maxRad < rads[i].global)
						maxRad = rads[i].global;
				if (minRad > rads[i].global)
						minRad = rads[i].global;
		}

		osg::ref_ptr<osg::TessellationHints> hints = new osg::TessellationHints;
		hints->setDetailRatio(0.5f);
		osg::Vec3 startColor = osg::Vec3(0, 1, 0);
		osg::Vec3 endColor = osg::Vec3(1, 0, 0);
		for (long i = 0; i < rads.size(); i++)
		{
				float linearPos = (rads[i].global - minRad) / maxRad;
				//osg::Vec4 color = colorRampImage->getColor((unsigned int)(linearPos * colorRampImage->s()), colorRampImage->t() / 2);

				/*osg::ref_ptr<osg::Material> mat = new osg::Material;
				mat->setColorMode(osg::Material::DIFFUSE);
				mat->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4(0.2, 0.2, 0.2, 1.0));
				mat->setDiffuse(osg::Material::FRONT_AND_BACK, color);
				mat->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4(1.0, 1.0, 1.0, 1.0));
				mat->setShininess(osg::Material::FRONT_AND_BACK, 64);*/
				osg::Vec3 color = startColor + (endColor - startColor) * linearPos;
				osg::ref_ptr< osg::ShapeDrawable> shapeDrawable = new osg::ShapeDrawable(new osg::Sphere(intersections[i].getWorldIntersectPoint(), 3), hints.get());
				//shapeDrawable->getOrCreateStateSet()->setAttributeAndModes(mat.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
				//shapeDrawable->getOrCreateStateSet()->addUniform(new osg::Uniform("color", osg::Vec3(color.r(), color.g(), color.b())));
				shapeDrawable->getOrCreateStateSet()->addUniform(new osg::Uniform("color", color));
				shapes->addDrawable(shapeDrawable.get());
		}
		bindColorShader(shapes->getOrCreateStateSet());
		//osg::ref_ptr<osg::Geometry> line = createLine(points);
		//osg::ref_ptr<osg::Geometry> pointgeo = createPoints(points);
		//shapes->addDrawable(line.get());
		//shapes->addDrawable(pointgeo.get());
		root->addChild(shapes.get());
		altAngle = 45;
		azimuthAngle = 0;

		int frameCount = 0;
		while (!viewer.done())
		{
				float sum = 0;
			//	frameCount++;
						//if (frameCount % 25 == 0)
				if (_canUpdateLightDir)
				{
						_canUpdateLightDir = false;
						//osgDB::writeImageFile(*img,"ortho.png");
						/*
						osg::Vec4* pShadowPos = (osg::Vec4*) img->data();
						double sum = 0;
						for (size_t i = 0; i < img->s() * img->t(); i++)
						{
								if (isnan(pShadowPos->z()))
										continue;
								sum += (pShadowPos->z());
						}
						printf("%f\n", sum/(img->s() * img->t()));*/

						//azimuthAngle = 0;
						azimuthAngle += 1;
						if (azimuthAngle >= 360)
						{
								altAngle += 1;
								azimuthAngle = 0;
						}

						if (altAngle >= 90)
						{
								altAngle = 45;
						}

						orthoCamera->reset2(localbb, altAngle, azimuthAngle);

						osg::Matrix lightMatrix = mat * orthoCamera->getViewMatrix() * orthoCamera->getProjectionMatrix()
								* osg::Matrix::scale(0.5, 0.5, 0.5)* osg::Matrix::translate(0.5, 0.5, 0.5);

						nodeWrapper->getOrCreateStateSet()->getUniform("lightMatrix")->set(lightMatrix);
						osg::Vec3 centerUV = orthoCamera->_center * lightMatrix;
						centerUV = minbound * lightMatrix;
						centerUV = maxbound * lightMatrix;
						nodeWrapper->getOrCreateStateSet()->getUniform("lightPos")->set(osg::Vec3(orthoCamera->_eye * mat));
				}
				//	if (altAngle > 85)
				//			altAngle = 15;
				//	mat = osg::Matrix::rotate(osg::DegreesToRadians(azimuthAngle), osg::Vec3(0, 0, 1));
				//	sceneNode->setMatrix(mat);

				/*	osg::BoundingBoxd transformedBB;
					transformedBB.init();
					for (size_t i = 0; i < 8; i++)
					{
							transformedBB.expandBy(localbb.corner(i) * mat);
					}
					localbb = BBWrapper(transformedBB);*/

				viewer.frame();
		}
		//printf("%f\n", 0.0);

		//altAngle = 90;
		//bool isFirst = true;

		//altAngle = 90;
		//while (altAngle > 5 && !viewer.done())
		//{
		//		azimuthAngle = 0;
		//		while (azimuthAngle < 360 && !viewer.done())
		//		{


		//				viewer.frame();
		//				//if (isFirst)
		//				//{
		//				//		while (pager->getRequestsInProgress())
		//				//		{
		//				//				viewer.frame();
		//				//		}
		//				//		isFirst = false;
		//				//}
		//				//viewer.frame();
		//				//orthoCamera->dirtyAttachmentMap();
		//				int count = 0;
		//				/*while (pager->getRequestsInProgress())
		//				{
		//						viewer.frame();
		//						count++;
		//						if (count > 5)
		//								break;
		//				}*/
		//				//std::stringstream ssoutname;
		//				//ssoutname << outdir << altAngle << "_" << azimuthAngle << ".png";
		//				//printf("%s\n", ssoutname.str().data());
		//				//osgDB::writeImageFile(*img, ssoutname.str().data());
		//				azimuthAngle += 12;
		//		}
		//			altAngle -= 3;
		//}

		//for (size_t i = 0; i < imageArr.size(); i++)
		//{
		//		ImageOutput* imageOutput = imageArr[i];
		//		imageOutput->Write(outdir);
		//		delete imageOutput;
		//}


		//GDALDataset *poSrcDS = (GDALDataset *)GDALOpen((outdir + "oblique.vrt").data(), GA_ReadOnly);

		//char **papszOptions = NULL;

		//papszOptions = CSLSetNameValue(papszOptions, "TILED", "YES");
		//papszOptions = CSLSetNameValue(papszOptions, "COMPRESS", "LZW");
		//GDALDataset * poDstDS = poDriver->CreateCopy((outdir + "oblique.tif").data(), poSrcDS, FALSE,
		//	papszOptions, GDALTermProgress, NULL);
		///* Once we're done, close properly the dataset */
		//if (poDstDS != NULL)
		//	GDALClose((GDALDatasetH)poDstDS);
		//CSLDestroy(papszOptions);
		//GDALClose((GDALDatasetH)poSrcDS);

		//poDriver->Delete((outdir + "oblique.vrt").data());
		//for (size_t i = 0; i < tilefiles.size(); i++)
		//{
		//	if (QFileInfo(tilefiles[i].data()).exists())
		//		QFile::remove(tilefiles[i].data());
		//}

		return viewer.run();
		//exit(0);
}

